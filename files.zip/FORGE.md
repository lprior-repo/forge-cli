# FORGE.md

**Type-safe serverless infrastructure using Go + Lingon + Terraform**

## Core Idea

Replace serverless.tf's HCL-based approach with Go types + Lingon to get:
- Compile-time validation
- Unit testable infrastructure
- IDE autocompletion
- Refactoring support
- All terraform-aws-lambda/apigateway-v2 options (200+ config params)

## Architecture

```
forge.config.hcl → ForgeConfig (Go) → NewForgeStack() → Lingon Resources → terra.Export() → main.tf
```

## Key Files

- `config_types.go`: All configuration structs (HCL → Go)
- `stack.go`: Converts config → Lingon resources
- `example_main.go`: Usage examples

## Implementation Strategy

### Phase 1: Core Types (DONE)
- ✓ Complete ForgeConfig with 200+ options
- ✓ All terraform-aws-lambda parameters
- ✓ All terraform-aws-apigateway-v2 parameters
- ✓ DynamoDB, EventBridge, Step Functions, S3, SNS, SQS

### Phase 2: Lingon Integration (IN PROGRESS)
- Generate AWS provider: `terragen -provider aws=hashicorp/aws:5.0.0`
- Implement resource creation functions
- Handle dependencies and references (e.g., `${table.users.arn}`)

### Phase 3: Build System
- Integrate with terraform-aws-lambda's package.py
- Support npm, pip, poetry
- Docker builds with SSH agent
- Pattern-based file inclusion/exclusion

### Phase 4: Testing
- Unit tests for stack generation
- Integration tests with terraform plan
- SAM CLI local testing support

## Patterns from serverless.tf

1. **Source Path Flexibility**
   - String: direct path
   - List: multiple sources
   - Object: patterns + dependencies + commands

2. **IAM Policy Composition**
   - Attach managed policies
   - Inline policy JSON
   - Policy statements (structured)
   - Auto-attach for common patterns (logs, VPC, tracing)

3. **Event Source Mapping**
   - DynamoDB streams with filtering
   - SQS with batch config
   - Kinesis with parallelization

4. **API Gateway Integration**
   - HTTP routing from function config
   - Auto-create integrations
   - JWT/Lambda authorizers
   - CORS configuration

## Reference Resolution

Handle Forge's `${}` syntax:
```hcl
environment = {
  TABLE_NAME = "${table.users.name}"
  QUEUE_URL  = "${queue.tasks.url}"
}
```

Convert to Lingon resource references:
```go
Environment: map[string]terra.Value{
  "TABLE_NAME": stack.Tables["users"].Table.Attributes().Name(),
  "QUEUE_URL":  stack.SQSQueues["tasks"].Queue.Attributes().Url(),
}
```

## Build Package Logic

From terraform-aws-lambda package.py:
1. Calculate content hash (filename = hash)
2. Check if package exists
3. If not, execute build:
   - Apply patterns
   - Run npm/pip/poetry
   - Execute custom commands
   - Create ZIP
4. Store locally or S3
5. Return package location

## Deployment Patterns

### Simple (publish=true)
- New version on code change
- Invoke via version number or $LATEST

### Aliases
- Point to version(s)
- Enable weighted routing (canary)
- Multiple aliases per function

### CodeDeploy
- Blue/green deployments
- Rollback on CloudWatch alarms
- Traffic shifting configurations

## Testing Strategy

```go
func TestStackGeneration(t *testing.T) {
  config := loadConfig("test.config.hcl")
  stack, err := NewForgeStack(config)
  require.NoError(t, err)
  
  // Verify resources created
  assert.NotNil(t, stack.Functions["api"])
  assert.NotNil(t, stack.APIGateway)
}

func TestTerraformPlan(t *testing.T) {
  // Export to HCL
  terra.Export(stack, "test-output/")
  
  // Run terraform plan
  cmd := exec.Command("terraform", "plan", "-out=plan.tfplan")
  cmd.Dir = "test-output"
  output, err := cmd.CombinedOutput()
  require.NoError(t, err)
  
  // Parse and verify plan
  // ...
}
```

## Key Decisions

1. **Go over HCL**: Type safety, testing, refactoring
2. **Lingon over CDK**: Terraform ecosystem, state management
3. **Complete parity**: All terraform-aws-lambda options, not subset
4. **Batteries included**: Smart defaults, easy overrides
5. **Single tool**: Terraform for everything (vs Serverless Framework + TF)

## Next Actions

1. Generate AWS provider with terragen
2. Implement createLambdaFunctionResources() fully
3. Implement createAPIGatewayResources() with auto-routing
4. Add reference resolution system
5. Integrate package.py logic
6. Write comprehensive tests
7. Add CLI tool for common operations

## Questions to Resolve

1. How to handle package.py Python dependency?
   - Options: Embed, shell out, rewrite in Go
2. Should we support Terragrunt?
   - Probably yes for multi-environment orchestration
3. Custom resource types via Go plugins?
   - For organization-specific resources

## Success Metrics

- Generate valid Terraform for all examples
- Pass `terraform plan` without errors
- Deploy successfully to AWS
- 100% test coverage on critical paths
- Documentation with examples for all features
- <100ms generation time for typical stack

## Resources

- terraform-aws-lambda: https://github.com/terraform-aws-modules/terraform-aws-lambda
- Lingon docs: https://pkg.go.dev/github.com/golingon/lingon
- serverless.tf: https://serverless.tf
- terraform-exec: https://github.com/hashicorp/terraform-exec
