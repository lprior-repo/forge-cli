# Forge: Serverless Infrastructure Platform

> Type-safe, testable, Go-based serverless infrastructure using Lingon and Terraform

Forge is a batteries-included platform for building serverless applications on AWS using Go. It combines the best patterns from serverless.tf with the type safety and testability of Go through Lingon.

## Overview

Forge provides:

- **Complete parity with serverless.tf** - All 170+ Lambda configuration options, 80+ API Gateway options, and more
- **Type-safe configuration** - Catch errors at compile time, not runtime
- **Testable infrastructure** - Unit test your infrastructure code like any other Go code
- **Batteries included** - Sensible defaults that follow AWS best practices
- **Full customization** - Override any default when needed
- **Context Engineering** - Minimal output, maximum signal in FORGE.md

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     forge.config.hcl                        │
│                  (Your Configuration)                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                   ForgeConfig (Go)                          │
│              Parsed HCL → Go Structs                        │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                  NewForgeStack()                            │
│         Converts Config → Lingon Resources                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    ForgeStack                               │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐           │
│  │  Lambda    │  │ API Gateway│  │  DynamoDB  │           │
│  │ Functions  │  │            │  │   Tables   │           │
│  └────────────┘  └────────────┘  └────────────┘           │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐           │
│  │   Layers   │  │EventBridge │  │    SQS     │           │
│  └────────────┘  └────────────┘  └────────────┘           │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              terra.Export(stack)                            │
│         Generates Terraform HCL from Go                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    main.tf                                  │
│              (Terraform Configuration)                      │
└─────────────────────────────────────────────────────────────┘
```

## Key Concepts

### 1. Serverless.tf Patterns

Forge implements serverless.tf's proven patterns:

- **Unified tool** - One tool (Terraform via Lingon) for all infrastructure
- **Build & package** - Automated building of Lambda packages with dependencies
- **Deploy strategies** - Support for blue/green, canary, rollback via CodeDeploy
- **Battle-tested modules** - Based on terraform-aws-modules (200M+ provisions)

### 2. Lingon Integration

Lingon provides:

- **Type-safe Terraform** - Write Terraform resources in Go
- **Provider generation** - Auto-generate Go types from Terraform providers
- **No HCL templating** - Use Go's language features (loops, conditionals, functions)
- **Testability** - Unit test infrastructure with standard Go testing

### 3. Context Engineering

Following David Anderson's flow principles:

- **FORGE.md** - Single source of truth for project context
- **Minimal output** - Only essential information
- **Maximum signal** - High information density
- **Fast iteration** - Quick feedback loops

## Quick Start

### Prerequisites

```bash
# Install Go 1.21+
go install golang.org/dl/go1.21.0@latest

# Install Lingon tools
go install github.com/golingon/lingon/cmd/terragen@latest

# Install Terraform
brew install terraform  # or your package manager
```

### Generate AWS Provider

```bash
# Generate Go code for AWS provider
terragen \
  -out ./aws \
  -pkg yourmodule/aws \
  -provider aws=hashicorp/aws:5.0.0 \
  -force
```

This generates type-safe Go structs for all AWS resources.

### Create Your First Function

Create `forge.config.hcl`:

```hcl
project_name = "my-api"
environment  = "development"
region       = "us-east-1"

terraform_backend = {
  bucket         = "my-terraform-state"
  dynamodb_table = "terraform-locks"
  encrypt        = true
}

function "hello" {
  description = "Hello world function"
  handler     = "index.handler"
  runtime     = "nodejs20.x"
  
  source = {
    path = "src/hello"
  }
  
  http = {
    method = "GET"
    path   = "/hello"
  }
}

api_gateway = {
  name          = "my-api"
  protocol_type = "HTTP"
  
  stage = {
    name        = "dev"
    auto_deploy = true
  }
}

tags = {
  Project     = "my-api"
  Environment = "development"
}
```

### Generate and Deploy

```go
package main

import (
    "log"
    "github.com/hashicorp/hcl/v2/hclsimple"
    "yourmodule/forge"
)

func main() {
    // Parse config
    var config forge.ForgeConfig
    err := hclsimple.DecodeFile("forge.config.hcl", nil, &config)
    if err != nil {
        log.Fatal(err)
    }
    
    // Create stack
    stack, err := forge.NewForgeStack(&config)
    if err != nil {
        log.Fatal(err)
    }
    
    // Export to Terraform
    terra.Export(stack, "output/")
}
```

```bash
# Run generator
go run main.go

# Initialize and apply
cd output/
terraform init
terraform apply
```

## Configuration Reference

### Lambda Functions

All terraform-aws-lambda options supported:

```hcl
function "my-function" {
  name        = "my-function"
  description = "Description"
  handler     = "index.handler"
  runtime     = "nodejs20.x"
  
  # Source Configuration
  source = {
    path = "src/my-function"
    
    # Pattern matching
    patterns = [
      "!**/*.test.ts",
      "node_modules/**"
    ]
    
    # Dependencies
    npm_requirements = true
    pip_requirements = "requirements.txt"
    poetry_install   = true
    
    # Custom commands
    commands = [
      "npm run build",
      ":zip dist output"
    ]
    
    prefix_in_zip = "app/"
  }
  
  # Resources
  timeout              = 30
  memory_size          = 1024
  architectures        = ["arm64"]
  ephemeral_storage_size = 2048
  
  # Concurrency
  reserved_concurrent_executions    = 100
  provisioned_concurrent_executions = 5
  
  # Environment
  environment = {
    NODE_ENV = "production"
  }
  
  # VPC
  vpc = {
    subnet_ids         = ["subnet-123"]
    security_group_ids = ["sg-456"]
  }
  
  # EFS
  file_system_arn            = "arn:aws:elasticfilesystem:..."
  file_system_local_mount_path = "/mnt/data"
  
  # Layers
  layers = [
    "arn:aws:lambda:...:layer:my-layer:1"
  ]
  
  # Dead Letter
  dead_letter_target_arn = "arn:aws:sqs:...:dlq"
  
  # Tracing
  tracing_mode = "Active"
  
  # Async Configuration
  maximum_event_age_in_seconds = 3600
  maximum_retry_attempts       = 2
  destination_on_success       = "arn:aws:sqs:...:success"
  destination_on_failure       = "arn:aws:sns:...:failures"
  
  # Snap Start (Java)
  snap_start = true
  
  # IAM
  iam = {
    attach_cloudwatch_logs_policy = true
    attach_network_policy         = true
    attach_tracing_policy         = true
    
    policies = [
      "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"
    ]
    
    policy_statements = {
      dynamodb = {
        effect    = "Allow"
        actions   = ["dynamodb:GetItem", "dynamodb:PutItem"]
        resources = ["arn:aws:dynamodb:*:*:table/*"]
      }
    }
  }
  
  # Publishing
  publish = true
  
  # CloudWatch Logs
  cloudwatch_logs = {
    retention_in_days = 7
    log_group_class   = "STANDARD"
  }
  
  # HTTP Routing
  http = {
    method             = "POST"
    path               = "/api/users"
    authorization_type = "JWT"
    authorizer_id      = "${authorizer.cognito}"
  }
  
  # Event Source Mapping
  event_source_mapping = {
    dynamodb_stream = {
      event_source_arn  = "${table.users.stream_arn}"
      starting_position = "LATEST"
      batch_size        = 100
      
      filter_criteria = {
        pattern = jsonencode({
          eventName = ["INSERT", "MODIFY"]
        })
      }
    }
  }
  
  # EventBridge Rules
  eventbridge_rule "schedule" {
    schedule_expression = "rate(5 minutes)"
  }
  
  tags = {
    Function = "my-function"
  }
}
```

### API Gateway v2

All terraform-aws-apigateway-v2 options supported:

```hcl
api_gateway = {
  name          = "my-api"
  protocol_type = "HTTP"  # or "WEBSOCKET"
  
  # CORS
  cors = {
    allow_headers     = ["content-type", "authorization"]
    allow_methods     = ["GET", "POST", "PUT", "DELETE"]
    allow_origins     = ["*"]
    allow_credentials = false
    max_age           = 300
  }
  
  # Custom Domain
  domain_name         = "api.example.com"
  create_certificate  = true
  create_domain_records = true
  hosted_zone_name    = "example.com"
  
  # Stage
  stage = {
    name        = "production"
    auto_deploy = true
    
    throttle_settings = {
      burst_limit = 5000
      rate_limit  = 10000
    }
    
    access_log_settings = {
      create_log_group         = true
      log_group_retention_days = 30
      format = jsonencode({
        requestId = "$context.requestId"
        ip        = "$context.identity.sourceIp"
        # ...
      })
    }
  }
  
  # Authorizers
  authorizer "cognito" {
    authorizer_type  = "JWT"
    identity_sources = ["$request.header.Authorization"]
    
    jwt_configuration = {
      audience = ["123456789"]
      issuer   = "https://cognito-idp.us-east-1.amazonaws.com/..."
    }
  }
}
```

### DynamoDB Tables

```hcl
table "users" {
  hash_key  = "userId"
  range_key = "timestamp"
  
  attribute {
    name = "userId"
    type = "S"
  }
  attribute {
    name = "timestamp"
    type = "N"
  }
  
  billing_mode = "PAY_PER_REQUEST"
  
  global_secondary_index {
    name            = "EmailIndex"
    hash_key        = "email"
    projection_type = "ALL"
  }
  
  stream_enabled   = true
  stream_view_type = "NEW_AND_OLD_IMAGES"
  
  ttl_enabled        = true
  ttl_attribute_name = "expiresAt"
  
  point_in_time_recovery_enabled = true
  
  server_side_encryption = {
    enabled = true
  }
}
```

## Build System

Forge supports multiple build patterns:

### Node.js with NPM

```hcl
source = {
  path = "src/my-function"
  npm_requirements = true
  commands = [
    "npm ci --production",
    "npm run build"
  ]
  patterns = [
    "!**/*.test.ts",
    "node_modules/**"
  ]
}
```

### Python with pip

```hcl
source = {
  path = "src/my-function"
  pip_requirements = "requirements.txt"
  patterns = [
    "!**/*.pyc",
    "!__pycache__/**"
  ]
}
```

### Python with Poetry

```hcl
source = {
  path = "src/my-function"
  poetry_install = true
}
```

### Docker Builds

```hcl
build = {
  docker = {
    enabled   = true
    image     = "public.ecr.aws/sam/build-python3.12"
    with_ssh_agent = true
  }
}
```

## Deployment Strategies

### Blue/Green with CodeDeploy

```hcl
deployment = {
  alias "live" {
    name            = "live"
    function_version = "$LATEST"
  }
  
  codedeploy = {
    enabled              = true
    deployment_config_name = "CodeDeployDefault.LambdaLinear10PercentEvery1Minute"
    alarm_names          = ["${alarm.high-error-rate.name}"]
    
    auto_rollback_configuration = {
      enabled = true
      events  = ["DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"]
    }
  }
}
```

### Canary Deployments

```hcl
deployment = {
  alias "production" {
    name            = "production"
    function_version = "5"
    
    routing_config = {
      additional_version_weights = {
        "6" = 0.1  # Route 10% to new version
      }
    }
  }
}
```

## Testing

### Unit Testing Infrastructure

```go
func TestLambdaFunction(t *testing.T) {
    config := &forge.ForgeConfig{
        ProjectName: "test",
        Environment: "test",
        Region:      "us-east-1",
        Functions: []forge.FunctionConfig{
            {
                Name:    "test-function",
                Handler: "index.handler",
                Runtime: "nodejs20.x",
                Source: forge.SourceConfig{
                    Path: "src/test",
                },
            },
        },
    }
    
    stack, err := forge.NewForgeStack(config)
    require.NoError(t, err)
    require.NotNil(t, stack.Functions["test-function"])
    
    // Verify IAM role created
    require.NotNil(t, stack.Functions["test-function"].Role)
    
    // Verify CloudWatch logs
    require.NotNil(t, stack.Functions["test-function"].LogGroup)
}
```

### Integration Testing with SAM CLI

```bash
# Local testing
sam local invoke --hook-name terraform function.hello-world

# API testing
sam local start-api --hook-name terraform

# With debugging
sam local invoke --hook-name terraform --debug-port 5858 function.hello-world
```

## Best Practices

### 1. Structure Your Project

```
my-serverless-app/
├── forge.config.hcl       # Main configuration
├── main.go                # Generator
├── src/
│   ├── functions/
│   │   ├── api-handler/
│   │   └── stream-processor/
│   └── layers/
│       └── shared-utils/
├── tests/
│   └── infrastructure_test.go
└── builds/                # Generated packages (gitignored)
```

### 2. Use Layers for Shared Code

```hcl
layer "shared-utils" {
  compatible_runtimes = ["nodejs20.x"]
  source = { path = "src/layers/shared-utils" }
}

function "api" {
  layers = ["${layer.shared-utils.arn}"]
  # ...
}
```

### 3. Separate Environments

```hcl
# dev.config.hcl
environment = "development"
timeout     = 300  # Longer for debugging

# prod.config.hcl  
environment = "production"
timeout     = 30
reserved_concurrent_executions = 100
```

### 4. Use References for Dependencies

```hcl
function "processor" {
  environment = {
    TABLE_NAME = "${table.users.name}"
    QUEUE_URL  = "${queue.tasks.url}"
  }
}
```

### 5. Tag Everything

```hcl
tags = {
  Project     = "my-app"
  Environment = "production"
  ManagedBy   = "forge"
  Team        = "platform"
  CostCenter  = "engineering"
}
```

## Comparison with Alternatives

| Feature | Forge | Serverless Framework | SAM | CDK | Pulumi |
|---------|-------|---------------------|-----|-----|--------|
| Language | Go | YAML/JS | YAML | TypeScript | Multi |
| Type Safety | ✓ | ✗ | ✗ | ✓ | ✓ |
| Testing | Go tests | Limited | Limited | Jest | Lang tests |
| Build System | Integrated | Plugins | Built-in | External | External |
| Terraform | ✓ | ✗ | ✗ | ✗ | Optional |
| AWS Only | ✓ | ✗ | ✓ | ✗ | ✗ |
| Learning Curve | Medium | Low | Low | Medium | Medium |

## Roadmap

- [ ] Complete Lingon resource implementation
- [ ] Add support for more AWS services (ECS, Fargate, AppSync)
- [ ] CI/CD pipeline generators
- [ ] Cost estimation integration
- [ ] Compliance checking (HIPAA, SOC2, etc.)
- [ ] Multi-region deployments
- [ ] Observability integration (Datadog, New Relic)

## Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md)

## License

MIT

## Credits

- Inspired by [serverless.tf](https://serverless.tf) by Anton Babenko
- Built with [Lingon](https://github.com/golingon/lingon) by Volvo Cars
- Uses [terraform-aws-modules](https://github.com/terraform-aws-modules) patterns

## Support

- GitHub Issues: https://github.com/yourorg/forge/issues
- Discussions: https://github.com/yourorg/forge/discussions
- Slack: https://forge-platform.slack.com
