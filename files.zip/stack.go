package forge

import (
	"fmt"

	"github.com/golingon/lingon/pkg/terra"
	// Import generated AWS provider - you'd generate this with terragen
	// Example: go run github.com/golingon/lingon/cmd/terragen -out ./aws -pkg forge/aws -provider aws=hashicorp/aws:5.0.0
	// "your-module/aws"
	// "your-module/aws/lambda"
	// "your-module/aws/apigatewayv2"
	// "your-module/aws/dynamodb"
)

// ForgeStack implements terra.Exporter and represents a complete serverless application
type ForgeStack struct {
	terra.Stack

	// Backend configuration
	Backend *S3Backend

	// Provider configuration
	Provider interface{} // *aws.Provider from generated code

	// Lambda Functions
	Functions map[string]*LambdaFunctionResources

	// Lambda Layers
	Layers map[string]*LambdaLayerResources

	// API Gateway
	APIGateway *APIGatewayResources

	// DynamoDB Tables
	Tables map[string]*DynamoDBTableResources

	// EventBridge
	EventBridge *EventBridgeResources

	// Step Functions
	StepFunctions map[string]*StepFunctionResources

	// S3 Buckets
	S3Buckets map[string]*S3BucketResources

	// SNS Topics
	SNSTopics map[string]*SNSTopicResources

	// SQS Queues
	SQSQueues map[string]*SQSQueueResources

	// CloudWatch Alarms
	CloudWatchAlarms map[string]interface{} // *cloudwatch.MetricAlarm
}

// S3Backend implements terra.Backend for S3
type S3Backend struct {
	Bucket        string `hcl:"bucket,attr"`
	Key           string `hcl:"key,attr"`
	Region        string `hcl:"region,attr"`
	DynamoDBTable string `hcl:"dynamodb_table,attr,optional"`
	Encrypt       bool   `hcl:"encrypt,attr,optional"`
}

// BackendType implements terra.Backend interface
func (b *S3Backend) BackendType() string {
	return "s3"
}

// LambdaFunctionResources contains all resources for a Lambda function
type LambdaFunctionResources struct {
	// Function resource
	Function interface{} // *lambda.Function

	// IAM Role
	Role interface{} // *iam.Role

	// IAM Policy attachments
	PolicyAttachments []interface{} // []*iam.RolePolicyAttachment

	// CloudWatch Log Group
	LogGroup interface{} // *cloudwatch_logs.LogGroup

	// Lambda Permissions
	Permissions []interface{} // []*lambda.Permission

	// Event Source Mappings
	EventSourceMappings map[string]interface{} // map[string]*lambda.EventSourceMapping

	// Function URL
	FunctionURL interface{} // *lambda.FunctionUrl

	// Async Event Config
	AsyncEventConfig interface{} // *lambda.FunctionEventInvokeConfig
}

// LambdaLayerResources contains all resources for a Lambda layer
type LambdaLayerResources struct {
	Layer interface{} // *lambda.LayerVersion
}

// APIGatewayResources contains all resources for API Gateway
type APIGatewayResources struct {
	API              interface{}            // *apigatewayv2.Api
	Stage            interface{}            // *apigatewayv2.Stage
	DomainName       interface{}            // *apigatewayv2.DomainName
	APIMapping       interface{}            // *apigatewayv2.ApiMapping
	Authorizers      map[string]interface{} // map[string]*apigatewayv2.Authorizer
	Integrations     map[string]interface{} // map[string]*apigatewayv2.Integration
	Routes           map[string]interface{} // map[string]*apigatewayv2.Route
	VPCLink          interface{}            // *apigatewayv2.VpcLink
	LogGroup         interface{}            // *cloudwatch_logs.LogGroup
}

// DynamoDBTableResources contains all resources for a DynamoDB table
type DynamoDBTableResources struct {
	Table                  interface{}   // *dynamodb.Table
	AutoscalingTargets     []interface{} // []*appautoscaling.Target
	AutoscalingPolicies    []interface{} // []*appautoscaling.Policy
}

// EventBridgeResources contains all resources for EventBridge
type EventBridgeResources struct {
	EventBus interface{}            // *cloudwatch_events.EventBus
	Rules    map[string]interface{} // map[string]*cloudwatch_events.Rule
	Targets  map[string]interface{} // map[string]*cloudwatch_events.Target
	Archives map[string]interface{} // map[string]*cloudwatch_events.Archive
}

// StepFunctionResources contains all resources for Step Functions
type StepFunctionResources struct {
	StateMachine interface{} // *sfn.StateMachine
	Role         interface{} // *iam.Role
	LogGroup     interface{} // *cloudwatch_logs.LogGroup
}

// S3BucketResources contains all resources for S3 bucket
type S3BucketResources struct {
	Bucket                            interface{} // *s3.Bucket
	BucketVersioning                  interface{} // *s3.BucketVersioningA
	BucketServerSideEncryptionConfig  interface{} // *s3.BucketServerSideEncryptionConfigurationA
	BucketLifecycleConfiguration      interface{} // *s3.BucketLifecycleConfigurationA
	BucketPublicAccessBlock           interface{} // *s3.BucketPublicAccessBlock
}

// SNSTopicResources contains all resources for SNS topic
type SNSTopicResources struct {
	Topic         interface{}   // *sns.Topic
	Subscriptions []interface{} // []*sns.TopicSubscription
}

// SQSQueueResources contains all resources for SQS queue
type SQSQueueResources struct {
	Queue interface{} // *sqs.Queue
}

// NewForgeStack creates a new ForgeStack from ForgeConfig
func NewForgeStack(config *ForgeConfig) (*ForgeStack, error) {
	stack := &ForgeStack{
		Functions:        make(map[string]*LambdaFunctionResources),
		Layers:           make(map[string]*LambdaLayerResources),
		Tables:           make(map[string]*DynamoDBTableResources),
		StepFunctions:    make(map[string]*StepFunctionResources),
		S3Buckets:        make(map[string]*S3BucketResources),
		SNSTopics:        make(map[string]*SNSTopicResources),
		SQSQueues:        make(map[string]*SQSQueueResources),
		CloudWatchAlarms: make(map[string]interface{}),
	}

	// Configure backend
	if config.TerraformBackend != nil {
		stack.Backend = &S3Backend{
			Bucket:        config.TerraformBackend.Bucket,
			Key:           generateBackendKey(config),
			Region:        getRegion(config),
			DynamoDBTable: config.TerraformBackend.DynamoDBTable,
			Encrypt:       config.TerraformBackend.Encrypt,
		}
	}

	// Configure provider
	// stack.Provider = aws.NewProvider(aws.ProviderArgs{
	// 	Region: terra.String(config.Region),
	// })

	// Process Lambda Functions
	for _, fnConfig := range config.Functions {
		resources, err := createLambdaFunctionResources(config, &fnConfig)
		if err != nil {
			return nil, fmt.Errorf("creating Lambda function %s: %w", fnConfig.Name, err)
		}
		stack.Functions[fnConfig.Name] = resources
	}

	// Process Lambda Layers
	for _, layerConfig := range config.Layers {
		resources, err := createLambdaLayerResources(config, &layerConfig)
		if err != nil {
			return nil, fmt.Errorf("creating Lambda layer %s: %w", layerConfig.Name, err)
		}
		stack.Layers[layerConfig.Name] = resources
	}

	// Process API Gateway
	if config.APIGateway != nil {
		resources, err := createAPIGatewayResources(config, config.APIGateway, stack)
		if err != nil {
			return nil, fmt.Errorf("creating API Gateway: %w", err)
		}
		stack.APIGateway = resources
	}

	// Process DynamoDB Tables
	for _, tableConfig := range config.Tables {
		resources, err := createDynamoDBTableResources(config, &tableConfig)
		if err != nil {
			return nil, fmt.Errorf("creating DynamoDB table %s: %w", tableConfig.Name, err)
		}
		stack.Tables[tableConfig.Name] = resources
	}

	// Process other resources...

	return stack, nil
}

// Helper functions

func generateBackendKey(config *ForgeConfig) string {
	if config.TerraformBackend != nil && config.TerraformBackend.Key != "" {
		return config.TerraformBackend.Key
	}
	return fmt.Sprintf("%s/%s/terraform.tfstate", config.ProjectName, config.Environment)
}

func getRegion(config *ForgeConfig) string {
	if config.TerraformBackend != nil && config.TerraformBackend.Region != "" {
		return config.TerraformBackend.Region
	}
	return config.Region
}

func createLambdaFunctionResources(config *ForgeConfig, fnConfig *FunctionConfig) (*LambdaFunctionResources, error) {
	resources := &LambdaFunctionResources{
		PolicyAttachments:   make([]interface{}, 0),
		Permissions:         make([]interface{}, 0),
		EventSourceMappings: make(map[string]interface{}),
	}

	// In a real implementation, you would:
	// 1. Create IAM role with trust policy
	// 2. Attach managed policies based on fnConfig.IAM
	// 3. Create custom inline policies if specified
	// 4. Create CloudWatch Log Group
	// 5. Build/package the Lambda function code
	// 6. Create the Lambda function resource
	// 7. Create event source mappings
	// 8. Create permissions for allowed triggers
	// 9. Create async event config if specified

	// Example structure (actual implementation would use generated AWS provider):
	/*
	resources.Role = iam.NewRole("lambda_role_"+fnConfig.Name, iam.RoleArgs{
		Name: terra.String(fmt.Sprintf("%s-%s-%s-lambda-role", config.ProjectName, config.Environment, fnConfig.Name)),
		AssumeRolePolicy: terra.String(buildLambdaTrustPolicy()),
		Tags: mergeTags(config.Tags, fnConfig.Tags),
	})

	if fnConfig.IAM != nil && fnConfig.IAM.AttachCloudWatchLogsPolicy {
		resources.PolicyAttachments = append(resources.PolicyAttachments,
			iam.NewRolePolicyAttachment("logs_policy_"+fnConfig.Name, iam.RolePolicyAttachmentArgs{
				Role: resources.Role.(*iam.Role).Attributes().Name(),
				PolicyArn: terra.String("arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"),
			}),
		)
	}

	resources.Function = lambda.NewFunction("function_"+fnConfig.Name, lambda.FunctionArgs{
		FunctionName: terra.String(buildResourceName(config, fnConfig.Name)),
		Description: terra.String(fnConfig.Description),
		Handler: terra.String(fnConfig.Handler),
		Runtime: terra.String(fnConfig.Runtime),
		Role: resources.Role.(*iam.Role).Attributes().Arn(),
		// ... many more fields
	})
	*/

	return resources, nil
}

func createLambdaLayerResources(config *ForgeConfig, layerConfig *LayerConfig) (*LambdaLayerResources, error) {
	resources := &LambdaLayerResources{}

	// Implementation would create Lambda layer with source configuration
	/*
	resources.Layer = lambda.NewLayerVersion("layer_"+layerConfig.Name, lambda.LayerVersionArgs{
		LayerName: terra.String(buildResourceName(config, layerConfig.Name)),
		Description: terra.String(layerConfig.Description),
		CompatibleRuntimes: toTerraStringSlice(layerConfig.CompatibleRuntimes),
		// Source configuration...
	})
	*/

	return resources, nil
}

func createAPIGatewayResources(config *ForgeConfig, apiConfig *APIGatewayConfig, stack *ForgeStack) (*APIGatewayResources, error) {
	resources := &APIGatewayResources{
		Authorizers:  make(map[string]interface{}),
		Integrations: make(map[string]interface{}),
		Routes:       make(map[string]interface{}),
	}

	// Implementation would:
	// 1. Create API Gateway v2 API
	// 2. Create stage with logging and throttling
	// 3. Create custom domain if specified
	// 4. Create authorizers
	// 5. Create integrations for each Lambda function with HTTP routing
	// 6. Create routes connecting paths to integrations

	/*
	resources.API = apigatewayv2.NewApi("api", apigatewayv2.ApiArgs{
		Name: terra.String(apiConfig.Name),
		ProtocolType: terra.String(apiConfig.ProtocolType),
		// CORS configuration...
	})

	resources.Stage = apigatewayv2.NewStage("api_stage", apigatewayv2.StageArgs{
		ApiId: resources.API.(*apigatewayv2.Api).Attributes().Id(),
		Name: terra.String(apiConfig.Stage.Name),
		AutoDeploy: terra.Bool(apiConfig.Stage.AutoDeploy),
		// Logging, throttling, etc...
	})

	// Create integrations and routes for each function with HTTP config
	for name, fnResources := range stack.Functions {
		// Get HTTP config from function
		// Create integration
		// Create route
	}
	*/

	return resources, nil
}

func createDynamoDBTableResources(config *ForgeConfig, tableConfig *TableConfig) (*DynamoDBTableResources, error) {
	resources := &DynamoDBTableResources{
		AutoscalingTargets:  make([]interface{}, 0),
		AutoscalingPolicies: make([]interface{}, 0),
	}

	// Implementation would:
	// 1. Create DynamoDB table with attributes, keys, indexes
	// 2. Configure streams if enabled
	// 3. Configure TTL if enabled
	// 4. Configure PITR if enabled
	// 5. Configure encryption
	// 6. Create autoscaling targets and policies if configured

	/*
	attributes := make([]dynamodb.AttributeDefinition, len(tableConfig.Attributes))
	for i, attr := range tableConfig.Attributes {
		attributes[i] = dynamodb.AttributeDefinition{
			Name: terra.String(attr.Name),
			Type: terra.String(attr.Type),
		}
	}

	resources.Table = dynamodb.NewTable("table_"+tableConfig.Name, dynamodb.TableArgs{
		Name: terra.String(buildResourceName(config, tableConfig.Name)),
		BillingMode: terra.String(tableConfig.BillingMode),
		HashKey: terra.String(tableConfig.HashKey),
		RangeKey: terra.String(tableConfig.RangeKey),
		Attributes: attributes,
		// GSI, LSI, streams, etc...
	})
	*/

	return resources, nil
}

// Utility functions

func buildResourceName(config *ForgeConfig, name string) string {
	return fmt.Sprintf("%s-%s-%s", config.ProjectName, config.Environment, name)
}

func buildLambdaTrustPolicy() string {
	return `{
  "Version": "2012-10-17",
  "Statement": [{
    "Action": "sts:AssumeRole",
    "Principal": {
      "Service": "lambda.amazonaws.com"
    },
    "Effect": "Allow"
  }]
}`
}

func mergeTags(baseTags, resourceTags map[string]string) map[string]string {
	merged := make(map[string]string)
	for k, v := range baseTags {
		merged[k] = v
	}
	for k, v := range resourceTags {
		merged[k] = v
	}
	return merged
}

// toTerraStringSlice converts []string to terra string slice
// In actual implementation, use terra.String() for each element
func toTerraStringSlice(s []string) interface{} {
	return s
}
