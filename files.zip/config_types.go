package forge

import "time"

// ForgeConfig is the root configuration for a Forge serverless application
type ForgeConfig struct {
	ProjectName string `hcl:"project_name" validate:"required"`
	Environment string `hcl:"environment" validate:"required"`
	Region      string `hcl:"region" validate:"required"`

	TerraformBackend *BackendConfig           `hcl:"terraform_backend,block"`
	Functions        []FunctionConfig         `hcl:"function,block"`
	Layers           []LayerConfig            `hcl:"layer,block"`
	APIGateway       *APIGatewayConfig        `hcl:"api_gateway,block"`
	Tables           []TableConfig            `hcl:"table,block"`
	EventBridge      *EventBridgeConfig       `hcl:"eventbridge,block"`
	StepFunctions    []StepFunctionConfig     `hcl:"step_function,block"`
	S3Buckets        []S3BucketConfig         `hcl:"s3_bucket,block"`
	SNSTopics        []SNSTopicConfig         `hcl:"sns_topic,block"`
	SQSQueues        []SQSQueueConfig         `hcl:"sqs_queue,block"`
	CloudWatchAlarms []CloudWatchAlarmConfig  `hcl:"alarm,block"`
	Build            *BuildConfig             `hcl:"build,block"`
	Deployment       *DeploymentConfig        `hcl:"deployment,block"`
	Monitoring       *MonitoringConfig        `hcl:"monitoring,block"`
	Tags             map[string]string        `hcl:"tags,optional"`
}

// BackendConfig defines Terraform backend configuration
type BackendConfig struct {
	Bucket         string `hcl:"bucket" validate:"required"`
	Key            string `hcl:"key,optional"`
	DynamoDBTable  string `hcl:"dynamodb_table,optional"`
	Encrypt        bool   `hcl:"encrypt,optional"`
	Region         string `hcl:"region,optional"`
}

// FunctionConfig contains ALL terraform-aws-lambda configuration options
type FunctionConfig struct {
	// Basic Configuration
	Name        string `hcl:"name,label" validate:"required"`
	Description string `hcl:"description,optional"`
	Handler     string `hcl:"handler" validate:"required"`
	Runtime     string `hcl:"runtime" validate:"required"`

	// Source Configuration
	Source SourceConfig `hcl:"source,block" validate:"required"`

	// Resource Configuration
	Timeout              int      `hcl:"timeout,optional"`
	MemorySize           int      `hcl:"memory_size,optional"`
	Architectures        []string `hcl:"architectures,optional"`
	EphemeralStorageSize int      `hcl:"ephemeral_storage_size,optional"`

	// Concurrency
	ReservedConcurrentExecutions    int `hcl:"reserved_concurrent_executions,optional"`
	ProvisionedConcurrentExecutions int `hcl:"provisioned_concurrent_executions,optional"`

	// Environment
	Environment map[string]string `hcl:"environment,optional"`

	// VPC Configuration
	VPC *VPCConfig `hcl:"vpc,block"`

	// EFS Configuration
	FileSystemArn           string `hcl:"file_system_arn,optional"`
	FileSystemLocalMountPath string `hcl:"file_system_local_mount_path,optional"`

	// Layers
	Layers []string `hcl:"layers,optional"`

	// Dead Letter Configuration
	DeadLetterTargetArn string `hcl:"dead_letter_target_arn,optional"`

	// Tracing
	TracingMode string `hcl:"tracing_mode,optional"`

	// Async Configuration
	MaximumEventAgeInSeconds int    `hcl:"maximum_event_age_in_seconds,optional"`
	MaximumRetryAttempts     int    `hcl:"maximum_retry_attempts,optional"`
	DestinationOnSuccess     string `hcl:"destination_on_success,optional"`
	DestinationOnFailure     string `hcl:"destination_on_failure,optional"`

	// Snap Start (Java)
	SnapStart bool `hcl:"snap_start,optional"`

	// Code Signing
	CodeSigningConfigArn string `hcl:"code_signing_config_arn,optional"`

	// IAM Configuration
	IAM *IAMConfig `hcl:"iam,block"`

	// Publishing
	Publish bool `hcl:"publish,optional"`

	// Lambda@Edge
	LambdaAtEdge bool `hcl:"lambda_at_edge,optional"`

	// CloudWatch Logs
	CloudWatchLogs *CloudWatchLogsConfig `hcl:"cloudwatch_logs,block"`

	// KMS
	KMSKeyArn string `hcl:"kms_key_arn,optional"`

	// Image Configuration (for container images)
	ImageConfig *ImageConfig `hcl:"image_config,block"`
	ImageURI    string       `hcl:"image_uri,optional"`
	PackageType string       `hcl:"package_type,optional"`

	// Logging Configuration
	Logging *LoggingConfig `hcl:"logging,block"`

	// Invoke Mode
	InvokeMode string `hcl:"invoke_mode,optional"`

	// HTTP Routing (API Gateway integration)
	HTTP *HTTPRoutingConfig `hcl:"http,block"`

	// Event Source Mapping
	EventSourceMapping map[string]*EventSourceMappingConfig `hcl:"event_source_mapping,block"`

	// EventBridge Rules
	EventBridgeRules map[string]*EventBridgeRuleConfig `hcl:"eventbridge_rule,block"`

	// Allowed Triggers
	AllowedTriggers map[string]*AllowedTrigger `hcl:"allowed_trigger,block"`

	// Timeouts
	Timeouts *ResourceTimeouts `hcl:"timeouts,block"`

	// Tags
	Tags map[string]string `hcl:"tags,optional"`

	// Skip Destroy
	SkipDestroy bool `hcl:"skip_destroy,optional"`
}

// SourceConfig defines how to build and package the Lambda function
type SourceConfig struct {
	Path string `hcl:"path" validate:"required"`

	// Pattern Matching
	Patterns []string `hcl:"patterns,optional"`

	// NPM Configuration
	NPMRequirements bool   `hcl:"npm_requirements,optional"`
	NPMTmpDir       string `hcl:"npm_tmp_dir,optional"`

	// Python Configuration
	PipRequirements       interface{} `hcl:"pip_requirements,optional"` // bool or string
	PipTmpDir             string      `hcl:"pip_tmp_dir,optional"`
	PoetryInstall         bool        `hcl:"poetry_install,optional"`
	PoetryExportExtraArgs []string    `hcl:"poetry_export_extra_args,optional"`

	// Custom Commands
	Commands []string `hcl:"commands,optional"`

	// Prefix in ZIP
	PrefixInZip string `hcl:"prefix_in_zip,optional"`
}

// VPCConfig defines VPC configuration for Lambda
type VPCConfig struct {
	SubnetIDs                      []string `hcl:"subnet_ids" validate:"required"`
	SecurityGroupIDs               []string `hcl:"security_group_ids" validate:"required"`
	ReplaceSecurityGroupsOnDestroy bool     `hcl:"replace_security_groups_on_destroy,optional"`
	ReplacementSecurityGroupIDs    []string `hcl:"replacement_security_group_ids,optional"`
	IPv6AllowedForDualStack        bool     `hcl:"ipv6_allowed_for_dual_stack,optional"`
}

// IAMConfig defines IAM role and policy configuration
type IAMConfig struct {
	// Existing Role
	RoleArn string `hcl:"role_arn,optional"`

	// Auto-attach Policies
	AttachCloudWatchLogsPolicy        bool `hcl:"attach_cloudwatch_logs_policy,optional"`
	AttachDeadLetterPolicy            bool `hcl:"attach_dead_letter_policy,optional"`
	AttachNetworkPolicy               bool `hcl:"attach_network_policy,optional"`
	AttachTracingPolicy               bool `hcl:"attach_tracing_policy,optional"`
	AttachAsyncEventPolicy            bool `hcl:"attach_async_event_policy,optional"`
	AttachCreateLogGroupPermission    bool `hcl:"attach_create_log_group_permission,optional"`

	// Custom Policies
	AttachPolicy       bool     `hcl:"attach_policy,optional"`
	Policy             string   `hcl:"policy,optional"`
	AttachPolicies     bool     `hcl:"attach_policies,optional"`
	Policies           []string `hcl:"policies,optional"`
	NumberOfPolicies   int      `hcl:"number_of_policies,optional"`

	AttachPolicyJSON    bool     `hcl:"attach_policy_json,optional"`
	PolicyJSON          string   `hcl:"policy_json,optional"`
	AttachPolicyJSONs   bool     `hcl:"attach_policy_jsons,optional"`
	PolicyJSONs         []string `hcl:"policy_jsons,optional"`
	NumberOfPolicyJSONs int      `hcl:"number_of_policy_jsons,optional"`

	AttachPolicyStatements bool                   `hcl:"attach_policy_statements,optional"`
	PolicyStatements       map[string]interface{} `hcl:"policy_statements,optional"`

	// Assume Role Policy
	AssumeRolePolicyStatements map[string]interface{} `hcl:"assume_role_policy_statements,optional"`
	TrustedEntities            []interface{}          `hcl:"trusted_entities,optional"`

	// Role Configuration
	RoleName                   string            `hcl:"role_name,optional"`
	RoleDescription            string            `hcl:"role_description,optional"`
	RolePath                   string            `hcl:"role_path,optional"`
	RoleForceDetachPolicies    bool              `hcl:"role_force_detach_policies,optional"`
	RolePermissionsBoundary    string            `hcl:"role_permissions_boundary,optional"`
	RoleMaximumSessionDuration int               `hcl:"role_maximum_session_duration,optional"`
	RoleTags                   map[string]string `hcl:"role_tags,optional"`

	// Policy Configuration
	PolicyName string `hcl:"policy_name,optional"`
}

// CloudWatchLogsConfig defines CloudWatch Logs configuration
type CloudWatchLogsConfig struct {
	RetentionInDays     int               `hcl:"retention_in_days,optional"`
	KMSKeyID            string            `hcl:"kms_key_id,optional"`
	LogGroupClass       string            `hcl:"log_group_class,optional"`
	SkipDestroy         bool              `hcl:"skip_destroy,optional"`
	Tags                map[string]string `hcl:"tags,optional"`
	UseExistingLogGroup bool              `hcl:"use_existing,optional"`
}

// ImageConfig defines container image configuration
type ImageConfig struct {
	Command          []string `hcl:"command,optional"`
	EntryPoint       []string `hcl:"entry_point,optional"`
	WorkingDirectory string   `hcl:"working_directory,optional"`
}

// LoggingConfig defines advanced logging configuration
type LoggingConfig struct {
	ApplicationLogLevel string `hcl:"application_log_level,optional"`
	LogFormat           string `hcl:"log_format,optional"`
	LogGroup            string `hcl:"log_group,optional"`
	SystemLogLevel      string `hcl:"system_log_level,optional"`
}

// HTTPRoutingConfig defines API Gateway HTTP routing
type HTTPRoutingConfig struct {
	Method string `hcl:"method" validate:"required"`
	Path   string `hcl:"path" validate:"required"`

	// Authorization
	AuthorizationType string `hcl:"authorization_type,optional"`
	AuthorizerID      string `hcl:"authorizer_id,optional"`

	// Route Settings
	DetailedMetricsEnabled bool      `hcl:"detailed_metrics_enabled,optional"`
	Throttle               *Throttle `hcl:"throttle,block"`
}

// Throttle defines throttling configuration
type Throttle struct {
	BurstLimit int `hcl:"burst_limit,optional"`
	RateLimit  int `hcl:"rate_limit,optional"`
}

// EventSourceMappingConfig defines event source mapping
type EventSourceMappingConfig struct {
	EventSourceArn                    string `hcl:"event_source_arn" validate:"required"`
	StartingPosition                  string `hcl:"starting_position,optional"`
	StartingPositionTimestamp         string `hcl:"starting_position_timestamp,optional"`
	BatchSize                         int    `hcl:"batch_size,optional"`
	MaximumBatchingWindowInSeconds    int    `hcl:"maximum_batching_window_in_seconds,optional"`
	MaximumRecordAgeInSeconds         int    `hcl:"maximum_record_age_in_seconds,optional"`
	MaximumRetryAttempts              int    `hcl:"maximum_retry_attempts,optional"`
	ParallelizationFactor             int    `hcl:"parallelization_factor,optional"`
	BisectBatchOnFunctionError        bool   `hcl:"bisect_batch_on_function_error,optional"`
	TumblingWindowInSeconds           int    `hcl:"tumbling_window_in_seconds,optional"`
	FunctionResponseTypes             []string `hcl:"function_response_types,optional"`

	// Filtering
	FilterCriteria *FilterCriteria `hcl:"filter_criteria,block"`

	// Destination on Failure
	DestinationConfig *DestinationConfig `hcl:"destination_config,block"`
}

// FilterCriteria defines event filtering
type FilterCriteria struct {
	Pattern string `hcl:"pattern" validate:"required"`
}

// DestinationConfig defines destination configuration
type DestinationConfig struct {
	OnFailure *DestinationOnFailure `hcl:"on_failure,block"`
}

// DestinationOnFailure defines failure destination
type DestinationOnFailure struct {
	DestinationArn string `hcl:"destination_arn" validate:"required"`
}

// EventBridgeRuleConfig defines EventBridge rule
type EventBridgeRuleConfig struct {
	ScheduleExpression string `hcl:"schedule_expression,optional"`
	EventPattern       string `hcl:"event_pattern,optional"`
	Description        string `hcl:"description,optional"`
	State              string `hcl:"state,optional"`
}

// AllowedTrigger defines allowed trigger configuration
type AllowedTrigger struct {
	Principal      string `hcl:"principal,optional"`
	PrincipalOrgID string `hcl:"principal_org_id,optional"`
	Service        string `hcl:"service,optional"`
	SourceArn      string `hcl:"source_arn,optional"`
	SourceAccount  string `hcl:"source_account,optional"`
}

// ResourceTimeouts defines resource operation timeouts
type ResourceTimeouts struct {
	Create string `hcl:"create,optional"`
	Update string `hcl:"update,optional"`
	Delete string `hcl:"delete,optional"`
}

// LayerConfig defines Lambda Layer configuration
type LayerConfig struct {
	Name                     string   `hcl:"name,label" validate:"required"`
	Description              string   `hcl:"description,optional"`
	CompatibleRuntimes       []string `hcl:"compatible_runtimes,optional"`
	CompatibleArchitectures  []string `hcl:"compatible_architectures,optional"`
	LicenseInfo              string   `hcl:"license_info,optional"`
	SkipDestroy              bool     `hcl:"skip_destroy,optional"`

	// Source Configuration
	Source SourceConfig `hcl:"source,block" validate:"required"`

	// Storage
	StoreOnS3 bool   `hcl:"store_on_s3,optional"`
	S3Bucket  string `hcl:"s3_bucket,optional"`

	Tags map[string]string `hcl:"tags,optional"`
}

// APIGatewayConfig defines API Gateway v2 configuration
type APIGatewayConfig struct {
	Name         string `hcl:"name" validate:"required"`
	Description  string `hcl:"description,optional"`
	ProtocolType string `hcl:"protocol_type" validate:"required"`

	// CORS Configuration
	CORS *CORSConfig `hcl:"cors,block"`

	// Custom Domain
	DomainName          string   `hcl:"domain_name,optional"`
	Subdomains          []string `hcl:"subdomains,optional"`
	CreateCertificate   bool     `hcl:"create_certificate,optional"`
	CertificateArn      string   `hcl:"certificate_arn,optional"`
	CreateDomainRecords bool     `hcl:"create_domain_records,optional"`
	HostedZoneName      string   `hcl:"hosted_zone_name,optional"`

	// Mutual TLS
	MutualTLSAuthentication *MutualTLSConfig `hcl:"mutual_tls_authentication,block"`

	// Stage Configuration
	Stage *StageConfig `hcl:"stage,block" validate:"required"`

	// Authorizers
	Authorizers map[string]*AuthorizerConfig `hcl:"authorizer,block"`

	// VPC Link
	VPCLink *VPCLinkConfig `hcl:"vpc_link,block"`

	// OpenAPI Specification
	Body string `hcl:"body,optional"`

	// Additional Configuration
	DisableExecuteAPIEndpoint bool   `hcl:"disable_execute_api_endpoint,optional"`
	FailOnWarnings            bool   `hcl:"fail_on_warnings,optional"`
	IPAddressType             string `hcl:"ip_address_type,optional"`

	// WebSocket Configuration
	RouteKey                     string `hcl:"route_key,optional"`
	CredentialsArn               string `hcl:"credentials_arn,optional"`
	RouteSelectionExpression     string `hcl:"route_selection_expression,optional"`
	APIKeySelectionExpression    string `hcl:"api_key_selection_expression,optional"`

	Tags map[string]string `hcl:"tags,optional"`
}

// CORSConfig defines CORS configuration
type CORSConfig struct {
	AllowHeaders     []string `hcl:"allow_headers,optional"`
	AllowMethods     []string `hcl:"allow_methods,optional"`
	AllowOrigins     []string `hcl:"allow_origins,optional"`
	AllowCredentials bool     `hcl:"allow_credentials,optional"`
	ExposeHeaders    []string `hcl:"expose_headers,optional"`
	MaxAge           int      `hcl:"max_age,optional"`
}

// MutualTLSConfig defines Mutual TLS configuration
type MutualTLSConfig struct {
	TruststoreURI     string `hcl:"truststore_uri" validate:"required"`
	TruststoreVersion string `hcl:"truststore_version,optional"`
}

// StageConfig defines API Gateway stage configuration
type StageConfig struct {
	Name       string `hcl:"name" validate:"required"`
	AutoDeploy bool   `hcl:"auto_deploy,optional"`

	// Throttling
	ThrottleSettings *ThrottleSettings `hcl:"throttle_settings,block"`

	// Access Logs
	AccessLogSettings *AccessLogSettings `hcl:"access_log_settings,block"`

	// Default Route Settings
	DefaultRouteSettings *RouteSettings `hcl:"default_route_settings,block"`

	// Stage Variables
	Variables map[string]string `hcl:"variables,optional"`

	// Client Certificate
	ClientCertificateID string `hcl:"client_certificate_id,optional"`

	Tags map[string]string `hcl:"tags,optional"`
}

// ThrottleSettings defines throttle settings
type ThrottleSettings struct {
	BurstLimit int `hcl:"burst_limit,optional"`
	RateLimit  int `hcl:"rate_limit,optional"`
}

// AccessLogSettings defines access log settings
type AccessLogSettings struct {
	CreateLogGroup         bool   `hcl:"create_log_group,optional"`
	LogGroupRetentionDays  int    `hcl:"log_group_retention_days,optional"`
	LogGroupKMSKeyID       string `hcl:"log_group_kms_key_id,optional"`
	LogGroupClass          string `hcl:"log_group_class,optional"`
	Format                 string `hcl:"format,optional"`
}

// RouteSettings defines route settings
type RouteSettings struct {
	DetailedMetricsEnabled bool `hcl:"detailed_metrics_enabled,optional"`
	ThrottlingBurstLimit   int  `hcl:"throttling_burst_limit,optional"`
	ThrottlingRateLimit    int  `hcl:"throttling_rate_limit,optional"`
}

// AuthorizerConfig defines authorizer configuration
type AuthorizerConfig struct {
	Name            string   `hcl:"name" validate:"required"`
	AuthorizerType  string   `hcl:"authorizer_type" validate:"required"`
	IdentitySources []string `hcl:"identity_sources" validate:"required"`

	// JWT Configuration
	JWTConfiguration *JWTConfiguration `hcl:"jwt_configuration,block"`

	// Lambda Authorizer
	AuthorizerURI                  string `hcl:"authorizer_uri,optional"`
	AuthorizerPayloadFormatVersion string `hcl:"authorizer_payload_format_version,optional"`
	EnableSimpleResponses          bool   `hcl:"enable_simple_responses,optional"`
	AuthorizerResultTTLInSeconds   int    `hcl:"authorizer_result_ttl_in_seconds,optional"`
	AuthorizerCredentialsArn       string `hcl:"authorizer_credentials_arn,optional"`
}

// JWTConfiguration defines JWT configuration
type JWTConfiguration struct {
	Audience []string `hcl:"audience" validate:"required"`
	Issuer   string   `hcl:"issuer" validate:"required"`
}

// VPCLinkConfig defines VPC Link configuration
type VPCLinkConfig struct {
	Name              string   `hcl:"name" validate:"required"`
	SecurityGroupIDs  []string `hcl:"security_group_ids" validate:"required"`
	SubnetIDs         []string `hcl:"subnet_ids" validate:"required"`
}

// TableConfig defines DynamoDB table configuration
type TableConfig struct {
	Name     string `hcl:"name,label" validate:"required"`
	HashKey  string `hcl:"hash_key" validate:"required"`
	RangeKey string `hcl:"range_key,optional"`

	Attributes []AttributeConfig `hcl:"attribute,block" validate:"required"`

	// Billing
	BillingMode   string `hcl:"billing_mode,optional"`
	ReadCapacity  int    `hcl:"read_capacity,optional"`
	WriteCapacity int    `hcl:"write_capacity,optional"`

	// Indexes
	GlobalSecondaryIndexes []GSIConfig `hcl:"global_secondary_index,block"`
	LocalSecondaryIndexes  []LSIConfig `hcl:"local_secondary_index,block"`

	// Streams
	StreamEnabled  bool   `hcl:"stream_enabled,optional"`
	StreamViewType string `hcl:"stream_view_type,optional"`

	// TTL
	TTLEnabled       bool   `hcl:"ttl_enabled,optional"`
	TTLAttributeName string `hcl:"ttl_attribute_name,optional"`

	// Point-in-Time Recovery
	PointInTimeRecoveryEnabled bool `hcl:"point_in_time_recovery_enabled,optional"`

	// Server-Side Encryption
	ServerSideEncryption *ServerSideEncryption `hcl:"server_side_encryption,block"`

	// Deletion Protection
	DeletionProtectionEnabled bool `hcl:"deletion_protection_enabled,optional"`

	// Table Class
	TableClass string `hcl:"table_class,optional"`

	// Replicas
	ReplicaRegions []ReplicaConfig `hcl:"replica,block"`

	// Autoscaling
	Autoscaling *AutoscalingConfig `hcl:"autoscaling,block"`

	Tags map[string]string `hcl:"tags,optional"`
}

// AttributeConfig defines DynamoDB attribute
type AttributeConfig struct {
	Name string `hcl:"name" validate:"required"`
	Type string `hcl:"type" validate:"required"`
}

// GSIConfig defines Global Secondary Index
type GSIConfig struct {
	Name           string `hcl:"name" validate:"required"`
	HashKey        string `hcl:"hash_key" validate:"required"`
	RangeKey       string `hcl:"range_key,optional"`
	ProjectionType string `hcl:"projection_type" validate:"required"`
	ReadCapacity   int    `hcl:"read_capacity,optional"`
	WriteCapacity  int    `hcl:"write_capacity,optional"`
}

// LSIConfig defines Local Secondary Index
type LSIConfig struct {
	Name           string `hcl:"name" validate:"required"`
	RangeKey       string `hcl:"range_key" validate:"required"`
	ProjectionType string `hcl:"projection_type" validate:"required"`
}

// ServerSideEncryption defines encryption configuration
type ServerSideEncryption struct {
	Enabled    bool   `hcl:"enabled,optional"`
	KMSKeyArn  string `hcl:"kms_key_arn,optional"`
}

// ReplicaConfig defines table replica configuration
type ReplicaConfig struct {
	RegionName           string `hcl:"region_name" validate:"required"`
	PropagateTags        bool   `hcl:"propagate_tags,optional"`
	PointInTimeRecovery  bool   `hcl:"point_in_time_recovery,optional"`
}

// AutoscalingConfig defines autoscaling configuration
type AutoscalingConfig struct {
	Read  *AutoscalingTargetConfig `hcl:"read,block"`
	Write *AutoscalingTargetConfig `hcl:"write,block"`
}

// AutoscalingTargetConfig defines autoscaling target
type AutoscalingTargetConfig struct {
	TargetValue      float64 `hcl:"target_value" validate:"required"`
	ScaleInCooldown  int     `hcl:"scale_in_cooldown,optional"`
	ScaleOutCooldown int     `hcl:"scale_out_cooldown,optional"`
	MaxCapacity      int     `hcl:"max_capacity" validate:"required"`
	MinCapacity      int     `hcl:"min_capacity" validate:"required"`
}

// EventBridgeConfig defines EventBridge configuration
type EventBridgeConfig struct {
	EventBusName string                     `hcl:"event_bus_name,optional"`
	Rules        []EventBridgeRulesConfig   `hcl:"rule,block"`
	Archives     []EventBridgeArchiveConfig `hcl:"archive,block"`
}

// EventBridgeRulesConfig defines EventBridge rules
type EventBridgeRulesConfig struct {
	Name               string                      `hcl:"name,label" validate:"required"`
	Description        string                      `hcl:"description,optional"`
	ScheduleExpression string                      `hcl:"schedule_expression,optional"`
	EventPattern       string                      `hcl:"event_pattern,optional"`
	State              string                      `hcl:"state,optional"`
	Targets            []EventBridgeTargetConfig   `hcl:"target,block"`
}

// EventBridgeTargetConfig defines EventBridge target
type EventBridgeTargetConfig struct {
	Arn                string                  `hcl:"arn" validate:"required"`
	InputTransformer   *InputTransformer       `hcl:"input_transformer,block"`
	DeadLetterConfig   *DeadLetterConfig       `hcl:"dead_letter_config,block"`
	RetryPolicy        *RetryPolicy            `hcl:"retry_policy,block"`
}

// InputTransformer defines input transformation
type InputTransformer struct {
	InputPaths    map[string]string `hcl:"input_paths,optional"`
	InputTemplate string            `hcl:"input_template" validate:"required"`
}

// DeadLetterConfig defines dead letter configuration
type DeadLetterConfig struct {
	Arn string `hcl:"arn" validate:"required"`
}

// RetryPolicy defines retry policy
type RetryPolicy struct {
	MaximumEventAge      int `hcl:"maximum_event_age,optional"`
	MaximumRetryAttempts int `hcl:"maximum_retry_attempts,optional"`
}

// EventBridgeArchiveConfig defines EventBridge archive
type EventBridgeArchiveConfig struct {
	Name          string `hcl:"name,label" validate:"required"`
	Description   string `hcl:"description,optional"`
	EventPattern  string `hcl:"event_pattern,optional"`
	RetentionDays int    `hcl:"retention_days,optional"`
}

// StepFunctionConfig defines Step Functions configuration
type StepFunctionConfig struct {
	Name       string `hcl:"name,label" validate:"required"`
	Type       string `hcl:"type" validate:"required"`
	Definition string `hcl:"definition" validate:"required"`

	LoggingConfiguration *StepFunctionLoggingConfig `hcl:"logging_configuration,block"`
	TracingConfiguration *TracingConfiguration      `hcl:"tracing_configuration,block"`

	RoleArn string            `hcl:"role_arn,optional"`
	Tags    map[string]string `hcl:"tags,optional"`
}

// StepFunctionLoggingConfig defines Step Functions logging
type StepFunctionLoggingConfig struct {
	LogDestination       string `hcl:"log_destination" validate:"required"`
	IncludeExecutionData bool   `hcl:"include_execution_data,optional"`
	Level                string `hcl:"level,optional"`
}

// TracingConfiguration defines X-Ray tracing
type TracingConfiguration struct {
	Enabled bool `hcl:"enabled,optional"`
}

// S3BucketConfig defines S3 bucket configuration
type S3BucketConfig struct {
	Name string `hcl:"name,label" validate:"required"`

	Versioning                        *VersioningConfig         `hcl:"versioning,block"`
	ServerSideEncryptionConfiguration *SSEConfiguration         `hcl:"server_side_encryption_configuration,block"`
	LifecycleRules                    []LifecycleRuleConfig     `hcl:"lifecycle_rule,block"`

	// Public Access Block
	BlockPublicAcls       bool `hcl:"block_public_acls,optional"`
	BlockPublicPolicy     bool `hcl:"block_public_policy,optional"`
	IgnorePublicAcls      bool `hcl:"ignore_public_acls,optional"`
	RestrictPublicBuckets bool `hcl:"restrict_public_buckets,optional"`

	Tags map[string]string `hcl:"tags,optional"`
}

// VersioningConfig defines versioning configuration
type VersioningConfig struct {
	Enabled bool `hcl:"enabled,optional"`
}

// SSEConfiguration defines server-side encryption
type SSEConfiguration struct {
	Rule *SSERule `hcl:"rule,block" validate:"required"`
}

// SSERule defines encryption rule
type SSERule struct {
	ApplyServerSideEncryptionByDefault *SSEDefault `hcl:"apply_server_side_encryption_by_default,block" validate:"required"`
}

// SSEDefault defines default encryption
type SSEDefault struct {
	SSEAlgorithm   string `hcl:"sse_algorithm" validate:"required"`
	KMSMasterKeyID string `hcl:"kms_master_key_id,optional"`
}

// LifecycleRuleConfig defines lifecycle rule
type LifecycleRuleConfig struct {
	ID      string `hcl:"id" validate:"required"`
	Enabled bool   `hcl:"enabled,optional"`

	NoncurrentVersionExpiration *NoncurrentVersionExpiration `hcl:"noncurrent_version_expiration,block"`
}

// NoncurrentVersionExpiration defines noncurrent version expiration
type NoncurrentVersionExpiration struct {
	Days int `hcl:"days" validate:"required"`
}

// SNSTopicConfig defines SNS topic configuration
type SNSTopicConfig struct {
	Name         string `hcl:"name,label" validate:"required"`
	DisplayName  string `hcl:"display_name,optional"`
	
	KMSMasterKeyID  string `hcl:"kms_master_key_id,optional"`
	DeliveryPolicy  string `hcl:"delivery_policy,optional"`
	
	Subscriptions []SNSSubscriptionConfig `hcl:"subscription,block"`
	Tags          map[string]string       `hcl:"tags,optional"`
}

// SNSSubscriptionConfig defines SNS subscription
type SNSSubscriptionConfig struct {
	Protocol string `hcl:"protocol" validate:"required"`
	Endpoint string `hcl:"endpoint" validate:"required"`
}

// SQSQueueConfig defines SQS queue configuration
type SQSQueueConfig struct {
	Name string `hcl:"name,label" validate:"required"`

	// Message Settings
	VisibilityTimeoutSeconds int    `hcl:"visibility_timeout_seconds,optional"`
	MessageRetentionSeconds  int    `hcl:"message_retention_seconds,optional"`
	MaxMessageSize           int    `hcl:"max_message_size,optional"`
	DelaySeconds             int    `hcl:"delay_seconds,optional"`
	ReceiveWaitTimeSeconds   int    `hcl:"receive_wait_time_seconds,optional"`

	// FIFO
	FIFOQueue                  bool   `hcl:"fifo_queue,optional"`
	ContentBasedDeduplication  bool   `hcl:"content_based_deduplication,optional"`
	DeduplicationScope         string `hcl:"deduplication_scope,optional"`
	FIFOThroughputLimit        string `hcl:"fifo_throughput_limit,optional"`

	// Dead Letter Queue
	RedrivePolicy string `hcl:"redrive_policy,optional"`

	// Encryption
	KMSMasterKeyID                string `hcl:"kms_master_key_id,optional"`
	KMSDataKeyReusePeriodSeconds  int    `hcl:"kms_data_key_reuse_period_seconds,optional"`

	// Policy
	Policy string `hcl:"policy,optional"`

	Tags map[string]string `hcl:"tags,optional"`
}

// CloudWatchAlarmConfig defines CloudWatch alarm
type CloudWatchAlarmConfig struct {
	AlarmName          string            `hcl:"alarm_name,label" validate:"required"`
	ComparisonOperator string            `hcl:"comparison_operator" validate:"required"`
	EvaluationPeriods  int               `hcl:"evaluation_periods" validate:"required"`
	MetricName         string            `hcl:"metric_name" validate:"required"`
	Namespace          string            `hcl:"namespace" validate:"required"`
	Period             int               `hcl:"period" validate:"required"`
	Statistic          string            `hcl:"statistic" validate:"required"`
	Threshold          float64           `hcl:"threshold" validate:"required"`
	Dimensions         map[string]string `hcl:"dimensions,optional"`
	AlarmDescription   string            `hcl:"alarm_description,optional"`
	AlarmActions       []string          `hcl:"alarm_actions,optional"`
}

// BuildConfig defines build configuration
type BuildConfig struct {
	Docker *DockerBuildConfig `hcl:"docker,block"`

	ArtifactsDir               string `hcl:"artifacts_dir,optional"`
	RecreateMissingPackage     bool   `hcl:"recreate_missing_package,optional"`
	TriggerOnPackageTimestamp  bool   `hcl:"trigger_on_package_timestamp,optional"`
	HashExtra                  string `hcl:"hash_extra,optional"`
	IgnoreSourceCodeHash       bool   `hcl:"ignore_source_code_hash,optional"`

	// S3 Storage
	StoreOnS3                   bool              `hcl:"store_on_s3,optional"`
	S3Bucket                    string            `hcl:"s3_bucket,optional"`
	S3Prefix                    string            `hcl:"s3_prefix,optional"`
	S3ACL                       string            `hcl:"s3_acl,optional"`
	S3ServerSideEncryption      string            `hcl:"s3_server_side_encryption,optional"`
	S3KMSID                     string            `hcl:"s3_kms_key_id,optional"`
	S3ObjectStorageClass        string            `hcl:"s3_object_storage_class,optional"`
	S3ObjectTags                map[string]string `hcl:"s3_object_tags,optional"`
	S3ObjectTagsOnly            bool              `hcl:"s3_object_tags_only,optional"`
	S3ObjectOverrideDefaultTags bool              `hcl:"s3_object_override_default_tags,optional"`

	Quiet bool `hcl:"quiet,optional"`
}

// DockerBuildConfig defines Docker build configuration
type DockerBuildConfig struct {
	Enabled           bool        `hcl:"enabled,optional"`
	Image             string      `hcl:"image,optional"`
	File              string      `hcl:"file,optional"`
	BuildRoot         string      `hcl:"build_root,optional"`
	WithSSHAgent      bool        `hcl:"with_ssh_agent,optional"`
	AdditionalOptions []string    `hcl:"additional_options,optional"`
	Entrypoint        string      `hcl:"entrypoint,optional"`
	PipCache          interface{} `hcl:"pip_cache,optional"`
}

// DeploymentConfig defines deployment configuration
type DeploymentConfig struct {
	Aliases    map[string]*AliasConfig `hcl:"alias,block"`
	CodeDeploy *CodeDeployConfig       `hcl:"codedeploy,block"`
}

// AliasConfig defines Lambda alias
type AliasConfig struct {
	Name            string         `hcl:"name" validate:"required"`
	Description     string         `hcl:"description,optional"`
	FunctionVersion string         `hcl:"function_version" validate:"required"`
	RoutingConfig   *RoutingConfig `hcl:"routing_config,block"`
}

// RoutingConfig defines routing configuration
type RoutingConfig struct {
	AdditionalVersionWeights map[string]float64 `hcl:"additional_version_weights,optional"`
}

// CodeDeployConfig defines CodeDeploy configuration
type CodeDeployConfig struct {
	Enabled                   bool     `hcl:"enabled,optional"`
	DeploymentConfigName      string   `hcl:"deployment_config_name,optional"`
	AlarmNames                []string `hcl:"alarm_names,optional"`
	AutoRollbackConfiguration *AutoRollbackConfig `hcl:"auto_rollback_configuration,block"`
	TriggerConfigurations     []TriggerConfiguration `hcl:"trigger_configuration,block"`
}

// AutoRollbackConfig defines auto rollback configuration
type AutoRollbackConfig struct {
	Enabled bool     `hcl:"enabled,optional"`
	Events  []string `hcl:"events,optional"`
}

// TriggerConfiguration defines trigger configuration
type TriggerConfiguration struct {
	TriggerEvents     []string `hcl:"trigger_events" validate:"required"`
	TriggerName       string   `hcl:"trigger_name" validate:"required"`
	TriggerTargetArn  string   `hcl:"trigger_target_arn" validate:"required"`
}

// MonitoringConfig defines monitoring configuration
type MonitoringConfig struct {
	XRayTracingEnabled bool   `hcl:"xray_tracing_enabled,optional"`
	InsightsEnabled    bool   `hcl:"insights_enabled,optional"`
	CreateDashboard    bool   `hcl:"create_dashboard,optional"`
	DashboardName      string `hcl:"dashboard_name,optional"`
}
