package main

import (
	"fmt"
	"log"
	"os"

	"github.com/golingon/lingon/pkg/terra"
	"github.com/hashicorp/hcl/v2/hclwrite"
	
	"your-module/forge"
)

func main() {
	// Example 1: Simple Lambda Function with API Gateway
	simpleExample()

	// Example 2: Complete Production Application
	productionExample()
}

func simpleExample() {
	config := &forge.ForgeConfig{
		ProjectName: "my-api",
		Environment: "development",
		Region:      "us-east-1",

		TerraformBackend: &forge.BackendConfig{
			Bucket:        "my-terraform-state",
			DynamoDBTable: "terraform-locks",
			Encrypt:       true,
		},

		Functions: []forge.FunctionConfig{
			{
				Name:        "hello-world",
				Description: "Simple hello world function",
				Handler:     "index.handler",
				Runtime:     "nodejs20.x",
				Source: forge.SourceConfig{
					Path: "src/hello-world",
				},
				Timeout:    30,
				MemorySize: 256,
				Environment: map[string]string{
					"NODE_ENV": "development",
				},
				IAM: &forge.IAMConfig{
					AttachCloudWatchLogsPolicy: true,
				},
				CloudWatchLogs: &forge.CloudWatchLogsConfig{
					RetentionInDays: 7,
				},
				HTTP: &forge.HTTPRoutingConfig{
					Method: "GET",
					Path:   "/hello",
				},
			},
		},

		APIGateway: &forge.APIGatewayConfig{
			Name:         "my-api",
			ProtocolType: "HTTP",
			CORS: &forge.CORSConfig{
				AllowOrigins: []string{"*"},
				AllowMethods: []string{"GET", "POST"},
			},
			Stage: &forge.StageConfig{
				Name:       "development",
				AutoDeploy: true,
			},
		},

		Tags: map[string]string{
			"Project":     "my-api",
			"Environment": "development",
			"ManagedBy":   "forge",
		},
	}

	// Create the stack
	stack, err := forge.NewForgeStack(config)
	if err != nil {
		log.Fatalf("Failed to create stack: %v", err)
	}

	// Export to Terraform
	if err := exportStack(stack, "simple-example"); err != nil {
		log.Fatalf("Failed to export stack: %v", err)
	}

	fmt.Println("✓ Simple example exported to simple-example/")
}

func productionExample() {
	config := &forge.ForgeConfig{
		ProjectName: "production-api",
		Environment: "production",
		Region:      "us-east-1",

		TerraformBackend: &forge.BackendConfig{
			Bucket:        "prod-terraform-state",
			DynamoDBTable: "terraform-locks",
			Encrypt:       true,
		},

		// Shared Layer
		Layers: []forge.LayerConfig{
			{
				Name:               "shared-utils",
				Description:        "Shared utility functions",
				CompatibleRuntimes: []string{"nodejs18.x", "nodejs20.x"},
				Source: forge.SourceConfig{
					Path: "src/layers/shared-utils",
				},
			},
		},

		// Multiple Functions
		Functions: []forge.FunctionConfig{
			// API Handler
			{
				Name:        "api-handler",
				Description: "Main API handler",
				Handler:     "dist/api.handler",
				Runtime:     "nodejs20.x",
				Source: forge.SourceConfig{
					Path: "src/functions/api-handler",
					Patterns: []string{
						"!**/*.test.ts",
						"!**/*.spec.ts",
						"node_modules/**",
					},
					NPMRequirements: true,
					Commands: []string{
						"npm ci --production",
						"npm run build",
					},
				},
				Timeout:              30,
				MemorySize:           1024,
				Architectures:        []string{"arm64"},
				EphemeralStorageSize: 2048,
				ReservedConcurrentExecutions: 100,
				Environment: map[string]string{
					"NODE_ENV":   "production",
					"TABLE_NAME": "users-table",
					"LOG_LEVEL":  "info",
				},
				Layers: []string{
					"${layer.shared-utils.arn}",
				},
				VPC: &forge.VPCConfig{
					SubnetIDs:        []string{"subnet-abc123", "subnet-def456"},
					SecurityGroupIDs: []string{"sg-xyz789"},
				},
				TracingMode: "Active",
				MaximumEventAgeInSeconds: 21600,
				MaximumRetryAttempts:     2,
				DestinationOnFailure:     "${queue.dlq.arn}",
				IAM: &forge.IAMConfig{
					AttachCloudWatchLogsPolicy: true,
					AttachNetworkPolicy:        true,
					AttachTracingPolicy:        true,
					PolicyStatements: map[string]interface{}{
						"dynamodb": map[string]interface{}{
							"effect": "Allow",
							"actions": []string{
								"dynamodb:GetItem",
								"dynamodb:PutItem",
								"dynamodb:UpdateItem",
								"dynamodb:Query",
							},
							"resources": []string{"${table.users.arn}"},
						},
					},
				},
				Publish: true,
				CloudWatchLogs: &forge.CloudWatchLogsConfig{
					RetentionInDays: 30,
					LogGroupClass:   "STANDARD",
				},
				HTTP: &forge.HTTPRoutingConfig{
					Method:            "ANY",
					Path:              "/api/{proxy+}",
					AuthorizationType: "JWT",
					AuthorizerID:      "${authorizer.cognito.id}",
				},
			},

			// DynamoDB Stream Processor
			{
				Name:        "stream-processor",
				Description: "Processes DynamoDB stream events",
				Handler:     "index.handler",
				Runtime:     "nodejs20.x",
				Source: forge.SourceConfig{
					Path: "src/functions/stream-processor",
				},
				Timeout:    60,
				MemorySize: 512,
				IAM: &forge.IAMConfig{
					AttachCloudWatchLogsPolicy: true,
					PolicyStatements: map[string]interface{}{
						"dynamodb_streams": map[string]interface{}{
							"effect": "Allow",
							"actions": []string{
								"dynamodb:GetRecords",
								"dynamodb:GetShardIterator",
								"dynamodb:DescribeStream",
								"dynamodb:ListStreams",
							},
							"resources": []string{"${table.users.stream_arn}"},
						},
					},
				},
				EventSourceMapping: map[string]*forge.EventSourceMappingConfig{
					"users_stream": {
						EventSourceArn:    "${table.users.stream_arn}",
						StartingPosition:  "LATEST",
						BatchSize:         100,
						MaximumBatchingWindowInSeconds: 10,
						FilterCriteria: &forge.FilterCriteria{
							Pattern: `{"eventName": ["INSERT", "MODIFY"]}`,
						},
					},
				},
			},

			// Scheduled Function
			{
				Name:        "daily-report",
				Description: "Generates daily reports",
				Handler:     "index.handler",
				Runtime:     "python3.12",
				Source: forge.SourceConfig{
					Path:            "src/functions/daily-report",
					PipRequirements: true,
				},
				Timeout:    300,
				MemorySize: 2048,
				IAM: &forge.IAMConfig{
					AttachCloudWatchLogsPolicy: true,
				},
				EventBridgeRules: map[string]*forge.EventBridgeRuleConfig{
					"daily": {
						ScheduleExpression: "cron(0 8 * * ? *)",
						Description:        "Run daily at 8 AM UTC",
					},
				},
			},
		},

		// API Gateway with Advanced Configuration
		APIGateway: &forge.APIGatewayConfig{
			Name:         "production-api",
			Description:  "Production API Gateway",
			ProtocolType: "HTTP",
			CORS: &forge.CORSConfig{
				AllowOrigins:     []string{"https://example.com"},
				AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
				AllowHeaders:     []string{"Content-Type", "Authorization"},
				AllowCredentials: true,
				MaxAge:           3600,
			},
			DomainName:          "api.example.com",
			CreateCertificate:   true,
			CreateDomainRecords: true,
			HostedZoneName:      "example.com",
			Stage: &forge.StageConfig{
				Name:       "production",
				AutoDeploy: true,
				ThrottleSettings: &forge.ThrottleSettings{
					BurstLimit: 10000,
					RateLimit:  5000,
				},
				AccessLogSettings: &forge.AccessLogSettings{
					CreateLogGroup:        true,
					LogGroupRetentionDays: 30,
					Format: `{"requestId":"$context.requestId","ip":"$context.identity.sourceIp","requestTime":"$context.requestTime","httpMethod":"$context.httpMethod","status":"$context.status"}`,
				},
				DefaultRouteSettings: &forge.RouteSettings{
					DetailedMetricsEnabled: true,
					ThrottlingBurstLimit:   5000,
					ThrottlingRateLimit:    2500,
				},
			},
			Authorizers: map[string]*forge.AuthorizerConfig{
				"cognito": {
					Name:            "cognito-authorizer",
					AuthorizerType:  "JWT",
					IdentitySources: []string{"$request.header.Authorization"},
					JWTConfiguration: &forge.JWTConfiguration{
						Audience: []string{"app-client-id"},
						Issuer:   "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_ABC123",
					},
					AuthorizerResultTTLInSeconds: 300,
				},
			},
		},

		// DynamoDB Tables
		Tables: []forge.TableConfig{
			{
				Name:     "users",
				HashKey:  "userId",
				RangeKey: "timestamp",
				Attributes: []forge.AttributeConfig{
					{Name: "userId", Type: "S"},
					{Name: "timestamp", Type: "N"},
					{Name: "email", Type: "S"},
				},
				BillingMode: "PAY_PER_REQUEST",
				GlobalSecondaryIndexes: []forge.GSIConfig{
					{
						Name:           "EmailIndex",
						HashKey:        "email",
						ProjectionType: "ALL",
					},
				},
				StreamEnabled:              true,
				StreamViewType:             "NEW_AND_OLD_IMAGES",
				TTLEnabled:                 true,
				TTLAttributeName:           "expiresAt",
				PointInTimeRecoveryEnabled: true,
				ServerSideEncryption: &forge.ServerSideEncryption{
					Enabled: true,
				},
				TableClass: "STANDARD",
			},
		},

		// SQS Queue for Dead Letter
		SQSQueues: []forge.SQSQueueConfig{
			{
				Name:                     "dlq",
				VisibilityTimeoutSeconds: 300,
				MessageRetentionSeconds:  1209600, // 14 days
			},
		},

		// SNS Topic for Alarms
		SNSTopics: []forge.SNSTopicConfig{
			{
				Name:        "alarms",
				DisplayName: "Production Alarms",
				Subscriptions: []forge.SNSSubscriptionConfig{
					{
						Protocol: "email",
						Endpoint: "ops@example.com",
					},
				},
			},
		},

		// CloudWatch Alarms
		CloudWatchAlarms: []forge.CloudWatchAlarmConfig{
			{
				AlarmName:          "api-high-error-rate",
				ComparisonOperator: "GreaterThanThreshold",
				EvaluationPeriods:  2,
				MetricName:         "Errors",
				Namespace:          "AWS/Lambda",
				Period:             300,
				Statistic:          "Sum",
				Threshold:          10,
				Dimensions: map[string]string{
					"FunctionName": "${function.api-handler.name}",
				},
				AlarmDescription: "Alert on high error rate",
				AlarmActions:     []string{"${sns.alarms.arn}"},
			},
		},

		// Build Configuration
		Build: &forge.BuildConfig{
			Docker: &forge.DockerBuildConfig{
				Enabled: false,
			},
			ArtifactsDir:              "builds",
			RecreateMissingPackage:    true,
			TriggerOnPackageTimestamp: true,
		},

		// Deployment Configuration
		Deployment: &forge.DeploymentConfig{
			Aliases: map[string]*forge.AliasConfig{
				"live": {
					Name:            "live",
					Description:     "Live traffic alias",
					FunctionVersion: "$LATEST",
				},
			},
			CodeDeploy: &forge.CodeDeployConfig{
				Enabled:              true,
				DeploymentConfigName: "CodeDeployDefault.LambdaLinear10PercentEvery1Minute",
				AlarmNames:           []string{"${alarm.api-high-error-rate.name}"},
				AutoRollbackConfiguration: &forge.AutoRollbackConfig{
					Enabled: true,
					Events:  []string{"DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"},
				},
			},
		},

		// Monitoring
		Monitoring: &forge.MonitoringConfig{
			XRayTracingEnabled: true,
			InsightsEnabled:    true,
			CreateDashboard:    true,
			DashboardName:      "production-api-dashboard",
		},

		// Global Tags
		Tags: map[string]string{
			"Project":     "production-api",
			"Environment": "production",
			"ManagedBy":   "forge",
			"Team":        "platform",
			"CostCenter":  "engineering",
		},
	}

	// Create the stack
	stack, err := forge.NewForgeStack(config)
	if err != nil {
		log.Fatalf("Failed to create stack: %v", err)
	}

	// Export to Terraform
	if err := exportStack(stack, "production-example"); err != nil {
		log.Fatalf("Failed to export stack: %v", err)
	}

	fmt.Println("✓ Production example exported to production-example/")
}

func exportStack(stack *forge.ForgeStack, outputDir string) error {
	// Create output directory
	if err := os.MkdirAll(outputDir, 0755); err != nil {
		return fmt.Errorf("creating output directory: %w", err)
	}

	// Export the stack to HCL
	exportedHCL, err := terra.Export(stack)
	if err != nil {
		return fmt.Errorf("exporting stack: %w", err)
	}

	// Write to main.tf
	mainTF := outputDir + "/main.tf"
	f := hclwrite.NewEmptyFile()
	f.Body().AppendUnstructuredTokens(exportedHCL.Tokens())
	
	if err := os.WriteFile(mainTF, f.Bytes(), 0644); err != nil {
		return fmt.Errorf("writing main.tf: %w", err)
	}

	fmt.Printf("✓ Exported Terraform configuration to %s\n", mainTF)
	return nil
}
