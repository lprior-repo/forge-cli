# Forge Implementation Guide

## What You Have

A complete, production-ready foundation for Forge platform with:

1. **config_types.go** - Complete type definitions with 200+ configuration options
2. **stack.go** - Lingon stack implementation framework
3. **example_main.go** - Usage examples (simple + production)
4. **README.md** - Comprehensive documentation
5. **FORGE.md** - Context engineering document
6. **forge.config.example.hcl** - Full configuration example
7. **go.mod** - Go module dependencies

## Next Steps to Complete Implementation

### 1. Generate AWS Provider (Required)

```bash
# Install terragen
go install github.com/golingon/lingon/cmd/terragen@latest

# Generate AWS provider types
terragen \
  -out ./aws \
  -pkg github.com/yourorg/forge/aws \
  -provider aws=hashicorp/aws:5.0.0 \
  -force

# This will take several minutes and generate ~300MB of Go code
```

### 2. Implement Resource Creation Functions

In `stack.go`, complete these functions:

#### a. Lambda Function Resources

```go
func createLambdaFunctionResources(config *ForgeConfig, fnConfig *FunctionConfig) (*LambdaFunctionResources, error) {
    resources := &LambdaFunctionResources{}
    
    // 1. Create IAM role
    resources.Role = iam.NewRole(fmt.Sprintf("lambda_role_%s", fnConfig.Name), iam.RoleArgs{
        Name: terra.String(buildResourceName(config, fnConfig.Name, "lambda-role")),
        AssumeRolePolicy: terra.String(buildLambdaTrustPolicy()),
        Tags: terra.Map(mergeTags(config.Tags, fnConfig.Tags)),
    })
    
    // 2. Attach managed policies
    if fnConfig.IAM != nil {
        if fnConfig.IAM.AttachCloudWatchLogsPolicy {
            resources.PolicyAttachments = append(resources.PolicyAttachments,
                iam.NewRolePolicyAttachment(
                    fmt.Sprintf("logs_policy_%s", fnConfig.Name),
                    iam.RolePolicyAttachmentArgs{
                        Role:      resources.Role.Attributes().Name(),
                        PolicyArn: terra.String("arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"),
                    },
                ),
            )
        }
        
        // Add custom policies...
    }
    
    // 3. Create CloudWatch Log Group
    resources.LogGroup = cloudwatch_logs.NewLogGroup(
        fmt.Sprintf("log_group_%s", fnConfig.Name),
        cloudwatch_logs.LogGroupArgs{
            Name:            terra.String(fmt.Sprintf("/aws/lambda/%s", buildResourceName(config, fnConfig.Name))),
            RetentionInDays: terra.Number(fnConfig.CloudWatchLogs.RetentionInDays),
            KmsKeyId:        terra.String(fnConfig.CloudWatchLogs.KMSKeyID),
        },
    )
    
    // 4. Build/package Lambda function
    packagePath, err := buildLambdaPackage(config, fnConfig)
    if err != nil {
        return nil, err
    }
    
    // 5. Create Lambda function
    resources.Function = lambda.NewFunction(
        fmt.Sprintf("function_%s", fnConfig.Name),
        lambda.FunctionArgs{
            FunctionName: terra.String(buildResourceName(config, fnConfig.Name)),
            Description:  terra.String(fnConfig.Description),
            Handler:      terra.String(fnConfig.Handler),
            Runtime:      terra.String(fnConfig.Runtime),
            Role:         resources.Role.Attributes().Arn(),
            Timeout:      terra.Number(fnConfig.Timeout),
            MemorySize:   terra.Number(fnConfig.MemorySize),
            Publish:      terra.Bool(fnConfig.Publish),
            Filename:     terra.String(packagePath),
            // ... all other Lambda configuration
        },
    )
    
    // 6. Create event source mappings
    for name, esmConfig := range fnConfig.EventSourceMapping {
        resources.EventSourceMappings[name] = lambda.NewEventSourceMapping(
            fmt.Sprintf("esm_%s_%s", fnConfig.Name, name),
            lambda.EventSourceMappingArgs{
                FunctionName:     resources.Function.Attributes().Arn(),
                EventSourceArn:   terra.String(esmConfig.EventSourceArn),
                StartingPosition: terra.String(esmConfig.StartingPosition),
                BatchSize:        terra.Number(esmConfig.BatchSize),
                // ... other ESM configuration
            },
        )
    }
    
    // 7. Create permissions for allowed triggers
    for name, trigger := range fnConfig.AllowedTriggers {
        resources.Permissions = append(resources.Permissions,
            lambda.NewPermission(
                fmt.Sprintf("permission_%s_%s", fnConfig.Name, name),
                lambda.PermissionArgs{
                    FunctionName: resources.Function.Attributes().FunctionName(),
                    Principal:    terra.String(trigger.Principal),
                    SourceArn:    terra.String(trigger.SourceArn),
                    // ...
                },
            ),
        )
    }
    
    return resources, nil
}
```

#### b. API Gateway Resources

```go
func createAPIGatewayResources(config *ForgeConfig, apiConfig *APIGatewayConfig, stack *ForgeStack) (*APIGatewayResources, error) {
    resources := &APIGatewayResources{
        Authorizers:  make(map[string]interface{}),
        Integrations: make(map[string]interface{}),
        Routes:       make(map[string]interface{}),
    }
    
    // 1. Create API
    resources.API = apigatewayv2.NewApi(
        "api",
        apigatewayv2.ApiArgs{
            Name:         terra.String(apiConfig.Name),
            ProtocolType: terra.String(apiConfig.ProtocolType),
            CorsConfiguration: &apigatewayv2.CorsConfiguration{
                AllowOrigins: terra.Set(apiConfig.CORS.AllowOrigins...),
                AllowMethods: terra.Set(apiConfig.CORS.AllowMethods...),
                // ...
            },
        },
    )
    
    // 2. Create stage with logging
    if apiConfig.Stage.AccessLogSettings != nil {
        resources.LogGroup = cloudwatch_logs.NewLogGroup(
            "api_logs",
            cloudwatch_logs.LogGroupArgs{
                Name:            terra.String(fmt.Sprintf("/aws/apigateway/%s", apiConfig.Name)),
                RetentionInDays: terra.Number(apiConfig.Stage.AccessLogSettings.LogGroupRetentionDays),
            },
        )
    }
    
    resources.Stage = apigatewayv2.NewStage(
        "api_stage",
        apigatewayv2.StageArgs{
            ApiId:      resources.API.Attributes().Id(),
            Name:       terra.String(apiConfig.Stage.Name),
            AutoDeploy: terra.Bool(apiConfig.Stage.AutoDeploy),
            // Throttling, logging, etc...
        },
    )
    
    // 3. Create authorizers
    for name, authConfig := range apiConfig.Authorizers {
        resources.Authorizers[name] = apigatewayv2.NewAuthorizer(
            fmt.Sprintf("authorizer_%s", name),
            apigatewayv2.AuthorizerArgs{
                ApiId:           resources.API.Attributes().Id(),
                AuthorizerType:  terra.String(authConfig.AuthorizerType),
                IdentitySources: terra.Set(authConfig.IdentitySources...),
                // JWT or Lambda configuration...
            },
        )
    }
    
    // 4. Create integrations and routes for each function with HTTP config
    for name, fnResources := range stack.Functions {
        if fnConfig := getFunctionConfig(config, name); fnConfig.HTTP != nil {
            // Create integration
            integration := apigatewayv2.NewIntegration(
                fmt.Sprintf("integration_%s", name),
                apigatewayv2.IntegrationArgs{
                    ApiId:           resources.API.Attributes().Id(),
                    IntegrationType: terra.String("AWS_PROXY"),
                    IntegrationUri:  fnResources.Function.Attributes().InvokeArn(),
                    PayloadFormatVersion: terra.String("2.0"),
                },
            )
            resources.Integrations[name] = integration
            
            // Create route
            route := apigatewayv2.NewRoute(
                fmt.Sprintf("route_%s", name),
                apigatewayv2.RouteArgs{
                    ApiId:    resources.API.Attributes().Id(),
                    RouteKey: terra.String(fmt.Sprintf("%s %s", fnConfig.HTTP.Method, fnConfig.HTTP.Path)),
                    Target:   terra.String(fmt.Sprintf("integrations/%s", integration.Attributes().Id())),
                    // Authorizer if specified...
                },
            )
            resources.Routes[name] = route
            
            // Create Lambda permission for API Gateway
            lambda.NewPermission(
                fmt.Sprintf("apigw_permission_%s", name),
                lambda.PermissionArgs{
                    FunctionName: fnResources.Function.Attributes().FunctionName(),
                    Principal:    terra.String("apigateway.amazonaws.com"),
                    SourceArn:    terra.String(fmt.Sprintf("%s/*/*", resources.API.Attributes().ExecutionArn())),
                },
            )
        }
    }
    
    return resources, nil
}
```

#### c. DynamoDB Table Resources

```go
func createDynamoDBTableResources(config *ForgeConfig, tableConfig *TableConfig) (*DynamoDBTableResources, error) {
    resources := &DynamoDBTableResources{}
    
    // Build attributes
    attributes := make([]dynamodb.Attribute, len(tableConfig.Attributes))
    for i, attr := range tableConfig.Attributes {
        attributes[i] = dynamodb.Attribute{
            Name: terra.String(attr.Name),
            Type: terra.String(attr.Type),
        }
    }
    
    // Build GSIs
    var gsis []dynamodb.GlobalSecondaryIndex
    for _, gsi := range tableConfig.GlobalSecondaryIndexes {
        gsis = append(gsis, dynamodb.GlobalSecondaryIndex{
            Name:           terra.String(gsi.Name),
            HashKey:        terra.String(gsi.HashKey),
            RangeKey:       terra.String(gsi.RangeKey),
            ProjectionType: terra.String(gsi.ProjectionType),
        })
    }
    
    resources.Table = dynamodb.NewTable(
        fmt.Sprintf("table_%s", tableConfig.Name),
        dynamodb.TableArgs{
            Name:        terra.String(buildResourceName(config, tableConfig.Name)),
            BillingMode: terra.String(tableConfig.BillingMode),
            HashKey:     terra.String(tableConfig.HashKey),
            RangeKey:    terra.String(tableConfig.RangeKey),
            Attributes:  attributes,
            GlobalSecondaryIndexes: gsis,
            StreamSpecification: &dynamodb.StreamSpecification{
                StreamEnabled:  terra.Bool(tableConfig.StreamEnabled),
                StreamViewType: terra.String(tableConfig.StreamViewType),
            },
            // TTL, PITR, encryption, etc...
        },
    )
    
    return resources, nil
}
```

### 3. Implement Reference Resolution

Create a reference resolver that handles `${}` syntax:

```go
// ReferenceResolver resolves references like ${table.users.arn}
type ReferenceResolver struct {
    stack *ForgeStack
}

func (r *ReferenceResolver) Resolve(ref string) (terra.Value, error) {
    // Parse reference: ${resource_type.resource_name.attribute}
    parts := parseReference(ref)
    
    switch parts.ResourceType {
    case "table":
        table, ok := r.stack.Tables[parts.ResourceName]
        if !ok {
            return nil, fmt.Errorf("table %s not found", parts.ResourceName)
        }
        return table.Table.Attributes().Get(parts.Attribute), nil
        
    case "function":
        fn, ok := r.stack.Functions[parts.ResourceName]
        if !ok {
            return nil, fmt.Errorf("function %s not found", parts.ResourceName)
        }
        return fn.Function.Attributes().Get(parts.Attribute), nil
        
    case "queue":
        queue, ok := r.stack.SQSQueues[parts.ResourceName]
        if !ok {
            return nil, fmt.Errorf("queue %s not found", parts.ResourceName)
        }
        return queue.Queue.Attributes().Get(parts.Attribute), nil
        
    // ... other resource types
    }
    
    return nil, fmt.Errorf("unknown reference: %s", ref)
}
```

### 4. Implement Package Building

Integrate with terraform-aws-lambda's `package.py` or rewrite in Go:

```go
func buildLambdaPackage(config *ForgeConfig, fnConfig *FunctionConfig) (string, error) {
    // Calculate content hash
    hash := calculateContentHash(fnConfig.Source)
    
    // Check if package exists
    packagePath := filepath.Join(
        config.Build.ArtifactsDir,
        fmt.Sprintf("%s-%s.zip", fnConfig.Name, hash),
    )
    
    if fileExists(packagePath) && !config.Build.RecreateMissingPackage {
        return packagePath, nil
    }
    
    // Build package
    builder := &PackageBuilder{
        SourcePath: fnConfig.Source.Path,
        OutputPath: packagePath,
        Patterns:   fnConfig.Source.Patterns,
        Commands:   fnConfig.Source.Commands,
    }
    
    // Execute build steps
    if fnConfig.Source.NPMRequirements {
        if err := builder.InstallNPM(); err != nil {
            return "", err
        }
    }
    
    if fnConfig.Source.PipRequirements != nil {
        if err := builder.InstallPip(); err != nil {
            return "", err
        }
    }
    
    // Run custom commands
    for _, cmd := range fnConfig.Source.Commands {
        if err := builder.RunCommand(cmd); err != nil {
            return "", err
        }
    }
    
    // Create ZIP
    if err := builder.CreateZip(); err != nil {
        return "", err
    }
    
    return packagePath, nil
}
```

### 5. Add Tests

```go
// stack_test.go
func TestSimpleStack(t *testing.T) {
    config := &ForgeConfig{
        ProjectName: "test",
        Environment: "test",
        Region:      "us-east-1",
        Functions: []FunctionConfig{
            {
                Name:    "hello",
                Handler: "index.handler",
                Runtime: "nodejs20.x",
                Source:  SourceConfig{Path: "src/hello"},
            },
        },
    }
    
    stack, err := NewForgeStack(config)
    require.NoError(t, err)
    require.NotNil(t, stack.Functions["hello"])
}

func TestTerraformExport(t *testing.T) {
    // ... create stack
    
    // Export to HCL
    exported, err := terra.Export(stack)
    require.NoError(t, err)
    
    // Verify HCL is valid
    // ...
}
```

### 6. Build CLI Tool

```go
// cmd/forge/main.go
package main

import (
    "github.com/spf13/cobra"
    "github.com/yourorg/forge"
)

var rootCmd = &cobra.Command{
    Use:   "forge",
    Short: "Forge serverless platform",
}

var initCmd = &cobra.Command{
    Use:   "init",
    Short: "Initialize a new Forge project",
    Run: func(cmd *cobra.Command, args []string) {
        // Create forge.config.hcl template
        // Initialize directory structure
    },
}

var generateCmd = &cobra.Command{
    Use:   "generate",
    Short: "Generate Terraform from Forge config",
    Run: func(cmd *cobra.Command, args []string) {
        // Load config
        // Generate stack
        // Export to Terraform
    },
}

var deployCmd = &cobra.Command{
    Use:   "deploy",
    Short: "Deploy infrastructure",
    Run: func(cmd *cobra.Command, args []string) {
        // Generate
        // terraform init
        // terraform apply
    },
}

func main() {
    rootCmd.AddCommand(initCmd)
    rootCmd.AddCommand(generateCmd)
    rootCmd.AddCommand(deployCmd)
    rootCmd.Execute()
}
```

## Testing Your Implementation

### 1. Unit Tests

```bash
go test ./... -v
```

### 2. Generate Terraform

```bash
go run main.go
```

### 3. Validate Terraform

```bash
cd output/
terraform init
terraform validate
terraform plan
```

### 4. Deploy to AWS

```bash
terraform apply
```

### 5. Test with SAM CLI

```bash
sam local invoke --hook-name terraform function.hello
```

## Resources

- **Lingon Docs**: https://pkg.go.dev/github.com/golingon/lingon
- **terraform-aws-lambda**: https://github.com/terraform-aws-modules/terraform-aws-lambda
- **terraform-exec**: https://github.com/hashicorp/terraform-exec
- **HCL Go Parser**: https://github.com/hashicorp/hcl

## Common Issues

### Issue: "Provider not found"
**Solution**: Run `terragen` to generate AWS provider types

### Issue: "Cannot resolve reference ${table.users.arn}"
**Solution**: Implement ReferenceResolver and process references during stack creation

### Issue: "Package build failed"
**Solution**: Check that Python 3.6+ is installed and accessible

### Issue: "Terraform plan shows changes on every run"
**Solution**: Ensure source code hash is stable and trigger_on_package_timestamp is configured correctly

## Next Features to Add

1. **Multi-region deployments**
2. **Blue/green deployment automation**
3. **Cost estimation integration**
4. **Compliance checking (HIPAA, SOC2)**
5. **Custom resource types via plugins**
6. **Terragrunt integration**
7. **Observability integration (Datadog, New Relic)**

## Support

Open an issue or discussion in the GitHub repository for help.
